// backend.h
#include <stdio.h>
#include "parser.h"

int inorderOnAST(ASTnode_t *);