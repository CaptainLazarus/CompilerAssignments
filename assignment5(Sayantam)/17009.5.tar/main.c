#include "parser.h"
#include<stdio.h>
#include<stdlib.h>


int main()
{
    if(parser())
        printf("Accepted\n");
    else
        printf("Rejected\n");    
}
